var svd_web_pg =
[
    [ "Public Download Area", "svd_web_public_pg.html", [
      [ "Logging in", "svd_web_public_pg.html#login_downl_sec", null ],
      [ "Opening the CMSIS-SVD Download page", "svd_web_public_pg.html#open_downl_sec", null ],
      [ "Accepting the Silicon Vendor's License terms", "svd_web_public_pg.html#accept_EULA_sec", null ],
      [ "Downloading CMSIS-SVD files", "svd_web_public_pg.html#downl_downl_sec", null ]
    ] ],
    [ "Restricted Management Area", "svd_web_restricted_pg.html", [
      [ "Signing the agreement", "svd_web_restricted_pg.html#sign_agreement_sec", null ],
      [ "Logging in", "svd_web_restricted_pg.html#login_mgmnt_dd_sec", null ],
      [ "Opening the CMSIS-SVD Device Database page", "svd_web_restricted_pg.html#open_mgmnt_ss_sec", null ],
      [ "Managing the Device Database", "svd_web_restricted_pg.html#manage_dd_entries_sec", null ]
    ] ]
];